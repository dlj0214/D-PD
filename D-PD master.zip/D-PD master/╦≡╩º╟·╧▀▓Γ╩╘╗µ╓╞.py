
import numpy as np

# 定义起始值和终止值
start = 80
end = 12

# 定义稳定值
stable_value = 15

# 生成 50 个随机数
random_numbers = np.linspace(start, end, 50)

# 定义一个稳定区域的索引
stable_index = 23

# 在稳定区域内，将随机数固定为稳定值
random_numbers[stable_index:] = stable_value

# 在稳定区域前后，添加一些随机波动
random_numbers[:stable_index] += np.random.rand(stable_index) * 3
random_numbers[stable_index:] += np.random.rand(len(random_numbers) - stable_index) * 3

# 检查生成的随机数是否满足要求
for i in range(len(random_numbers)):
    if i >= stable_index:
        if random_numbers[i] < stable_value - 2 or random_numbers[i] > stable_value + 2:
            raise ValueError("Stable value is not within the specified range")
    else:
        if random_numbers[i] < start or random_numbers[i] > end:
            raise ValueError("Random numbers are not within the specified range")

# 打印生成的随机数列表
print(random_numbers)