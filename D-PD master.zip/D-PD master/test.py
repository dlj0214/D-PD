import torch

from rga_model import RGA_Branch

model = RGA_Branch(...)
dummy_input = torch.randn(1, 3, 224, 224)  # assuming input size is [256, 128, 3]
output = model(dummy_input   )
feature_size = output[0].size(1)
print(feature_size)