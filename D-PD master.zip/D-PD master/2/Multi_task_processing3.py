import os
from itertools import product

import numpy as np
from PIL import Image
from matplotlib import pyplot as plt
import torch.nn.functional as F
from numpy import shape
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm

from models_utils.rga_branches import RGA_Branch

import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
import seaborn as sns
from torchvision import transforms




class CustomDataset(Dataset):
    def __init__(self, data_dir, mode='train', modalities=[ 2]):
        self.data_dir = data_dir
        self.cls_label = ['d', 'ud']
        self.modalities = modalities
        self.data = []
        paths = os.listdir(data_dir)

        for path in paths:
            class_label = path.split(' ')[2]
            label_id = self.cls_label.index(class_label)
            p_features = path.split(' ')[1]
            regression_output = path.split(' ')[3]
            # print("class_label, label_id, p_features, regression_output")
            # print(class_label,label_id,p_features,regression_output)
            sub_dirs = os.path.join(data_dir, path)

            image_paths = {0: [], 1: [], 2: []}
            for sub_dir in os.listdir(sub_dirs):
                if sub_dir == '1':
                    module0_dir = os.path.join(sub_dirs, sub_dir)
                    image_paths[0] = [os.path.join(module0_dir, i) for i in os.listdir(module0_dir)]
                elif sub_dir == '2':
                    module1_dir = os.path.join(sub_dirs, sub_dir)
                    image_paths[1] = [os.path.join(module1_dir, i) for i in os.listdir(module1_dir)]
                else:
                    module2_dir = os.path.join(sub_dirs, sub_dir)
                    image_paths[2] = [os.path.join(module2_dir, i) for i in os.listdir(module2_dir)]

            for i in [0, 1, 2]:
                if not image_paths[i] or i not in self.modalities:
                    image_paths[i] = [self.generate_zero_image()]

            for ret in product(*[image_paths[i] for i in self.modalities]):
                result = ret + (label_id, float(p_features), float(regression_output))
                self.data.append(result)

        total_len = len(self.data)
        train_len = int(0.8 * total_len)
        val_len = int(0.1 * total_len)
        test_len = total_len - train_len - val_len

        indices = list(range(total_len))
        np.random.shuffle(indices)

        train_indices = indices[:train_len]
        val_indices = indices[train_len:train_len + val_len]
        test_indices = indices[train_len + val_len:]

        if mode == 'train':
            self.data = [self.data[i] for i in train_indices]
        elif mode == 'val':
            self.data = [self.data[i] for i in val_indices]
        elif mode == 'test':
            self.data = [self.data[i] for i in test_indices]
        print("First 5 data samples:")
        for sample in self.data[:5]:
            print(sample)
    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        data = self.data[index]

        # Initialize images with zero tensors for all modalities
        images = [self.generate_zero_image() for _ in range(3)]
        lst = [0,1,2]

        for i in self.modalities:
            if i in lst:

                if isinstance(data[i], str):  # Check if it's a string (path)
                # images[i] = self.load_image(data[idx])
                    images[i] = self.load_image(data[i])
            else:
                print(f"{i} 不在列表中")
        # Load only those images which are in the modalities list
        # for idx, i in enumerate(self.modalities):
        #     print(idx, i)
        #     if isinstance(data[idx], str):  # Check if it's a string (path)
        #         images[i] = self.load_image(data[idx])
        #     else:
        #         print(f"Unexpected data type at index {i}: {data[idx]}")

        label = torch.tensor(data[-3])
        p_feature = torch.tensor(data[-2])
        regression_output = torch.tensor(data[-1])
        return images, label, int(p_feature), regression_output

    def load_image(self, path):

        transform = transforms.Compose([
            transforms.Resize((224, 224)),  # 调整图像大小
            # transforms.RandomCrop(224),  # 随机裁剪
            # transforms.RandomRotation(10),  # 随机旋转
            transforms.ToTensor(),  # 转换为张量
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),  # 归一化
        ])

        if path == 'zero_image':
            return transform(Image.fromarray(np.zeros((224, 224, 3), dtype=np.uint8)))
        # print(path)
        # print("Image.open(path).convert('RGB')",Image.open(path).convert('RGB'))
        return transform(Image.open(path).convert('RGB'))

    def generate_zero_image(self):
        return torch.zeros((3, 224, 224))


import torch
import torch.nn as nn
import torchvision.models as models


class MultiTaskModel(nn.Module):
    def __init__(self, num_classes_regression, num_classes_classification,model="RGA_Branch"):
        super(MultiTaskModel, self).__init__()

        # ResNet,pretrained 表示是否需要预训练
        # self.resnet1 = models.resnet50(pretrained=False)
        # self.resnet2 = models.resnet50(pretrained=False)
        # self.resnet3 = models.resnet50(pretrained=False)
        if model!="RGA_Branch":
            self.resnet1 = RGA_Branch(pretrained=False)
            self.resnet2 = RGA_Branch(pretrained=False)
            self.resnet3 = RGA_Branch(pretrained=False)
        else:
            self.resnet1 = models.resnet50(pretrained=False)
            self.resnet2 = models.resnet50(pretrained=False)
            self.resnet3 = models.resnet50(pretrained=False)
        #         # resnet的全连接层的输出大小进行修改
        #         num_features_resnet = self.resnet1.fc.in_features
        #         self.resnet1.fc = nn.Linear(num_features_resnet, 128)
        #         self.resnet2.fc = nn.Linear(num_features_resnet, 128)
        #         self.resnet3.fc = nn.Linear(num_features_resnet, 128)

        # Resize image
        self.resize = transforms.Resize((224, 224), antialias=True)


        # resnet output features dim
        num_output_features = self.resnet1.fc.out_features
        # num_output_features = 14#self.resnet1.feat_bn
        # print(num_output_features)
        # self.feat_bn
        # Fully connected layers
        self.fc1 = nn.Linear(num_output_features, 32)
        self.fc2 = nn.Linear(num_output_features, 32)
        self.fc3 = nn.Linear(num_output_features, 32)

        # 定义三个独立的双向LSTM层
        lstm_hidden_size = 256
        input_size = self.fc1.out_features
        self.lstm1 = nn.LSTM(input_size=input_size, hidden_size=lstm_hidden_size, num_layers=1, bidirectional=True)
        self.lstm2 = nn.LSTM(input_size=input_size, hidden_size=lstm_hidden_size, num_layers=1, bidirectional=True)
        self.lstm3 = nn.LSTM(input_size=input_size, hidden_size=lstm_hidden_size, num_layers=1, bidirectional=True)

        # Dropout layer
        self.dropout = nn.Dropout(p=0.25)

        # Fusion layer
        self.fusion_fc = nn.Linear(1536, 32)

        # Regression task
        # self.fc_regression = nn.Linear(128, num_classes_regression)回归输出应该只有一个值。在这种情况下，您应该将 self.fc_regression 设置为输出大小为1
        self.fc_regression = nn.Linear(32, 1)

        # Regression task + P_feature
        self.fc_regression2 = nn.Linear(2, 1)


        # Classification task
        self.fc_classification = nn.Linear(32, num_classes_classification)

    def forward(self, x1, x2, x3, p_feature):
        # Resize images]

        x1 = self.resize(x1)
        x2 = self.resize(x2)
        x3 = self.resize(x3)

        x1 = x1[:, :3, :, :]
        x2 = x2[:, :3, :, :]
        x3 = x3[:, :3, :, :]

        # ResNet feature extraction
        resnet_features1 = self.resnet1(x1)
        resnet_features2 = self.resnet2(x2)
        resnet_features3 = self.resnet3(x3)

        # Fully connected layers
        fc_output1 = self.fc1(resnet_features1)
        fc_output2 = self.fc2(resnet_features2)
        fc_output3 = self.fc3(resnet_features3)

        # LSTM layers
        lstm_output1, _ = self.lstm1(fc_output1.unsqueeze(0))
        lstm_output2, _ = self.lstm2(fc_output2.unsqueeze(0))
        lstm_output3, _ = self.lstm3(fc_output3.unsqueeze(0))

        # Flatten LSTM outputs
        lstm_output1 = lstm_output1.view(lstm_output1.size(1), -1)
        lstm_output2 = lstm_output2.view(lstm_output2.size(1), -1)
        lstm_output3 = lstm_output3.view(lstm_output3.size(1), -1)

        # Concatenate LSTM outputs
        concatenated_features = torch.cat((lstm_output1, lstm_output2, lstm_output3), dim=1)

        # Fusion layer
        fusion_output = self.fusion_fc(concatenated_features)

        # Dropout
        dropout_output = self.dropout(fusion_output)

        # Regression task
        regression_output = self.fc_regression(dropout_output)

        # Concatenate regression_output with p_feature
        # combined_output = torch.cat((regression_output, p_feature.unsqueeze(0).reshape(4, 1)), dim=1)
        # combined_output = torch.cat((regression_output, p_feature.unsqueeze(1)), dim=1)
        # print(regression_output.shape)
        # regression_output = self.fc_regression2(regression_output)
        # Classification task
        classification_output = self.fc_classification(dropout_output)

        return classification_output, regression_output


# 定义损失函数
class MultiTaskLoss(nn.Module):
    def __init__(self, alpha, beta):
        super(MultiTaskLoss, self).__init__()
        self.alpha = alpha
        self.beta = beta
        self.classification_loss = nn.CrossEntropyLoss()
        self.regression_loss = nn.MSELoss()

    def forward(self, final_output, regression_output, classification_target, regression_target):
        classification_loss = self.classification_loss(final_output, classification_target)
        regression_loss = self.regression_loss(regression_output, regression_target)
        total_loss = self.alpha * classification_loss + self.beta * regression_loss
        return total_loss


device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = MultiTaskModel(46,5,"RGA_Branch")
model = model.to(device)

# 训练过程
from transformers import AdamW

# 假设您想每隔`save_interval`个epoch保存一次
save_interval = 5  # 例如，每5个epoch保存一次
file_path = "performance_metrics.txt"
num_epochs = 200
print_every = 100
batch_size = 64
learning_rate = 1e-4
optimizer = AdamW(model.parameters(), lr=learning_rate)
loss_fn = MultiTaskLoss(alpha=0.8, beta=0.2)

train_losses = []
val_losses = []

data="data"
modalitie=[ 0,1,2]
train_dataset = CustomDataset(data, mode='train', modalities=modalitie)
val_dataset = CustomDataset(data, mode='val', modalities=modalitie)
test_dataset = CustomDataset(data, mode='test', modalities=modalitie)

# 初始化两个列表来跟踪每个epoch的平均损失
avg_train_losses = []
avg_val_losses = []

from sklearn.metrics import confusion_matrix, precision_score, mean_squared_error, accuracy_score
import seaborn as sns

for epoch in range(num_epochs):
    true_y_cls = []
    pred_y_cls = []
    true_y_reg = []  # 初始化true_y_reg
    pred_y_reg = []  # 初始化pred_y_reg
    print(f"Length of val_dataset: {len(val_dataset)}")

    model.train()
    val_losses = []
    train_data_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    train_data_loader = tqdm(train_data_loader)

    total_train_loss = 0.0

    for i, (images, _, p_feature, regression_out) in enumerate(train_data_loader):
        optimizer.zero_grad()
        images = [img.to(device) for img in images]
        class_output, regression_output = model(*images, p_feature.to(device))

        # 使用 softmax 函数将输出映射到概率分布上
        probabilities = F.softmax(class_output, dim=1)

        # 选择概率最高的类别作为预测结果
        final_output = torch.argmax(probabilities, dim=1)

        # 将预测结果从 GPU 移动到 CPU，并转换为 NumPy 数组
        # final_output = final_output.cpu().numpy()

        regression_output = regression_output.view(-1)
        loss = loss_fn(class_output, regression_output, p_feature.to(device), regression_out.to(device))
        train_losses.append(loss.item())
        loss.backward()
        optimizer.step()
        total_train_loss += loss.item()

        if (i + 1) % print_every == 0:
            print(f'Epoch [{epoch + 1}/{num_epochs}], Step [{i + 1}/{len(train_data_loader)}], Loss: {loss.item():.4f}')

    avg_train_loss = total_train_loss / len(train_data_loader)
    avg_train_losses.append(avg_train_loss)

    model.eval()
    total_val_loss = 0.0

    with torch.no_grad():
        val_data_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=True)
        val_data_loader = tqdm(val_data_loader)

        for i, (images, _, p_feature, regression_out) in enumerate(val_data_loader):
            images = [img.to(device) for img in images]
            class_output, regression_output = model(images[0].to(device), images[1].to(device), images[2].to(device),
                                                    p_feature.to(device))

            # 使用 softmax 函数将输出映射到概率分布上
            probabilities = F.softmax(class_output, dim=1)

            # 选择概率最高的类别作为预测结果
            final_output = torch.argmax(probabilities, dim=1)

            # 将预测结果从 GPU 移动到 CPU，并转换为 NumPy 数组
            # final_output = final_output.cpu().numpy()

            regression_output = regression_output.view(-1)



            # 打印label和预测值的形状

            pred_y_cls.extend(final_output.to('cpu').numpy())  # 将tensor展平并转换为numpy数组
            true_y_cls.extend(p_feature.to('cpu').numpy())  # 将tensor展平并转换为numpy数组
            pred_y_reg.extend(regression_output.to('cpu').numpy())  # 将tensor展平并转换为numpy数组
            true_y_reg.extend(regression_out.to('cpu').numpy())  # 将tensor展平并转换为numpy数组
            # 打印true_y_cls和pred_y_cls的长度
            # print("结果：！！！！！！！！！！！！！！！")
            # print(regression_output,regression_out)
            # print(final_output, p_feature)
            loss = loss_fn(class_output, regression_output, p_feature.to(device), regression_out.to(device))
            val_losses.append(loss.item())

        avg_regression_loss = sum(val_losses) / len(val_losses)
        print(f'Epoch [{epoch + 1}/{num_epochs}], Validation Regression Loss: {avg_regression_loss:.4f}')

        model_save_path = "./saved_models/"
        if not os.path.exists(model_save_path):
            os.makedirs(model_save_path)
        model.cpu()
        torch.save(model.state_dict(), os.path.join(model_save_path, f'model_epoch_{epoch}.pth'))
        model.to(device)

    avg_val_loss = total_val_loss / len(val_data_loader)
    avg_val_losses.append(avg_val_loss)
    # ...
    # 在每个epoch结束后
    # 为混淆矩阵绘图
    print("为混淆矩阵绘图")
    print(true_y_cls,pred_y_cls)
    cm = confusion_matrix(true_y_cls, pred_y_cls)

    # 创建类别标签
    class_names = ["Class 0", "Class 1"]
    if epoch % save_interval == 0:
        # 绘制混淆矩阵
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=class_names, yticklabels=class_names)
        plt.xlabel("Predicted")
        plt.ylabel("Actual")
        plt.title(f"Confusion Matrix - Epoch {epoch}")
        # plt.show()
        plt.savefig(f'confusion_matrix_epoch_{epoch}.png')
        plt.close()  # 关闭图形，以便下一次绘制

        # 为回归预测绘图
    true_values = np.concatenate([tensor.flatten() for tensor in true_y_reg])
    pred_y_reg = [torch.from_numpy(np_array) if isinstance(np_array, np.ndarray) else np_array for np_array in
                  pred_y_reg]

    predicted_values = np.concatenate(
        [np.atleast_1d(tensor.detach().numpy()) if isinstance(tensor, torch.Tensor) else np.atleast_1d(np.array(tensor))
         for tensor in pred_y_reg]).flatten()
    if epoch % save_interval == 0:
        plt.figure(figsize=(10, 5))
        plt.scatter(true_values, predicted_values, label='Data Points')
        plt.plot(true_values, true_values, label='Perfect Prediction', color='red')
        plt.legend()
        plt.title(f"Regression Scatter - Epoch {epoch}")
        # plt.show()
        plt.savefig(f'regression_plot_epoch_{epoch}.png')
        plt.close()  # 关闭图形，以便下一次绘制
    # 计算并打印指标
    print("计算并打印指标")
    print(np.array(true_y_cls), np.array(pred_y_cls))
    acc = accuracy_score(np.array(true_y_cls), np.array(pred_y_cls))
    pre = precision_score(np.array(true_y_cls), np.array(pred_y_cls),average='macro')
    mse = mean_squared_error(true_values, predicted_values)

    print(f"Epoch {epoch} - ACC: {acc:.4f}, Precision: {pre:.4f}, MSE: {mse:.4f}")
    # 定义要保存到的文件路径


    # 打开文件以写入数据
    with open(file_path, "a") as file:
        # 写入性能指标到文件
        file.write(f"Epoch {epoch} - ACC: {acc:.4f}, Precision: {pre:.4f}, MSE: {mse:.4f}\n")

    #%%
# 可视化每个epoch的平均训练和验证损失
import matplotlib.pyplot as plt

# 绘制损失曲线
plt.figure(figsize=(10, 5))
plt.plot(range(len(avg_train_losses)), avg_train_losses, label='Train Loss')
plt.plot(range(len(avg_val_losses)), avg_val_losses, label='Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()

# 保存图像为文件
plt.savefig('loss_plot.png')

# 显示图像
plt.show()
